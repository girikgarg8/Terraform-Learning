import json


def handler(event, context):
    # Resolved numeric version (1 or 2) when using aliases / weighted routing.
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"function_version": context.function_version}),
    }
